enum FontDrawType_t
{
	FONT_DRAW_DEFAULT = 0,

	FONT_DRAW_NONADDITIVE,
	FONT_DRAW_ADDITIVE,

	FONT_DRAW_TYPE_COUNT = 2,
};

class ISurface
{
public:

	void DrawSetColor( Color color )
	{
		typedef void( __thiscall* _DrawSetColor )( void*, Color);
		return EmulateVirtual<_DrawSetColor>( this, 14 )( this, color);
	}

	void DrawOutlinedRect( int X, int Y, int W, int H )
	{
		typedef void( __thiscall* _DrawOutlinedRect )( void*, int, int, int, int );
		return EmulateVirtual<_DrawOutlinedRect>( this, 18 )( this, X, Y, W, H );
	}

	void DrawSetTextFont( int Font )
	{
		typedef void( __thiscall* _DrawSetTextFont )( void*, int );
		return EmulateVirtual<_DrawSetTextFont>( this, 23 )( this, Font );
	}

	void DrawSetTextColor(Color color)
	{
		typedef void(__thiscall* _DrawSetTextColor )( void*, Color);
		return EmulateVirtual<_DrawSetTextColor>( this, 24 )( this, color);
	}

	void DrawSetTextPos( int X, int Y )
	{
		typedef void( __thiscall* _DrawSetTextPos )( void*, int, int );
		return EmulateVirtual<_DrawSetTextPos>( this, 26 )( this, X, Y );
	}

	void DrawPrintText(const wchar_t* text, int textLen, FontDrawType_t drawType = FONT_DRAW_DEFAULT)
	{
		typedef void(__thiscall* OriginalFn)(void*, const wchar_t*, int, FontDrawType_t);
		return EmulateVirtual< OriginalFn >(this, 28)(this, text, textLen, drawType);
	}

	bool GetTextSize( int Font, const wchar_t* _Input, int& Wide, int& Tall )
	{
		typedef bool( __thiscall* _GetTextSize )( void*, int, const wchar_t*, int&, int& );
		return EmulateVirtual< _GetTextSize >( this, 79 )( this, Font, _Input, Wide, Tall );
	}

	void DrawFilledRect(int x0, int y0, int x1, int y1)
	{
		typedef void(__thiscall* OriginalFn)(void*, int, int, int, int);
		return EmulateVirtual< OriginalFn >(this, 16)(this, x0, y0, x1, y1);
	}

	void DrawLine(int x0, int y0, int x1, int y1)
	{
		typedef void(__thiscall* OriginalFn)(void*, int, int, int, int);
		return EmulateVirtual< OriginalFn >(this, 19)(this, x0, y0, x1, y1);
	}

}; extern ISurface * Surface;