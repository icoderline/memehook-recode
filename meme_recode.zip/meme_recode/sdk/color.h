class Color
{
public:

	unsigned char _RGBA[4];

	Color(int R, int G, int B, int A)
	{
		_RGBA[0] = (unsigned char)R;
		_RGBA[1] = (unsigned char)G;
		_RGBA[2] = (unsigned char)B;
		_RGBA[3] = (unsigned char)A;
	}

	Color(int R, int G, int B)
	{
		Color(R, G, B, 255);
	}

	void GetColor(int& _r, int& _g, int& _b, int& _a) const
	{
		_r = _RGBA[0];
		_g = _RGBA[1];
		_b = _RGBA[2];
		_a = _RGBA[3];
	}

	int r() const { return _RGBA[0]; }
	int g() const { return _RGBA[1]; }
	int b() const { return _RGBA[2]; }
	int a() const { return _RGBA[3]; }
};