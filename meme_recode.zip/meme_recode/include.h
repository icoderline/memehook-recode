#define _CRT_SECURE_NO_WARNINGS

#include <Windows.h>
#include <stdio.h>
#include <iostream>
#include <string>

#include "hack\tools.h"

#pragma region sdk
#include "sdk\color.h"
#include "sdk\cvar.h"
#include "sdk\panel.h"
#include "sdk\surface.h"
#include "sdk\engine.h"
#pragma endregion


IPanel * Panel;
ISurface * Surface;
IVEngineClient * Engine;
ICVar * Cvar;
Tool * Get;

HWND hwCSGO;
bool bMenuOpen = false;
bool bMeme;

Hooked * PaintTravers;
#include "hack\menu\vars.h"
#include "hack\interfaces.h"
#include "hack\hook.h"