#include "include.h"

DWORD WINAPI Run(LPVOID threadParam)
{
	hwCSGO = FindWindow(NULL, "Counter-Strike: Global Offensive");

	Interface::Run();
	Hook::Run();

	return TRUE;
}

BOOL WINAPI DllMain(HINSTANCE instance, DWORD reason, LPVOID reserved)
{
	if (reason != DLL_PROCESS_ATTACH)
		return TRUE;

	CreateThread(NULL, NULL, Run, NULL, NULL, NULL);
	return TRUE;
}