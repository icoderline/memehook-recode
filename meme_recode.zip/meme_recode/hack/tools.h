class Tool
{
public:
	typedef void*	(*Fn)(char* _Name, int Return);
	virtual void* Interface(char* _Module, char* _Interface)
	{
		Fn TempInterface = (Fn)GetProcAddress(GetModuleHandle(_Module), "CreateInterface");

		return (void*)TempInterface(_Interface, 0);
	}

}; extern Tool * Get;


template< typename Function > Function EmulateVirtual(void* _VMT, int Index)
{
	void*** _TVMT = (void***)_VMT;

	void** VMT = *_TVMT;

	void* _Address = VMT[Index];

	return (Function)(_Address);
}

class Hooked
{
private:
	int vtable;
	int orig;
	int orig_protect;
	DWORD hk;
	int ent;
	int offs;
public:
	Hooked(void* instance)
	{
		vtable = *((int*)instance);
	}

	DWORD HookMethod(DWORD dwNewFunc, unsigned int iIndex)
	{
		int entry = vtable + sizeof(int) * iIndex;
		int org = *((int*)entry);

		int org_protect = Unprotect((void*)entry);
		*((int*)entry) = (int)dwNewFunc;

		orig = org;
		hk = dwNewFunc;
		ent = entry;

		return orig;
	}

	void* Original()
	{
		return (void*)orig;
	}

	void* ReHook()
	{
		*((int*)ent) = (int)hk;
		return (void*)orig;
	}

	void UnHook()
	{
		*((int*)ent) = (int)orig;
	}

	void Revert()
	{
		*((int*)ent) = (int)orig;
		Protect((void*)ent, orig_protect);
	}

	void Protect(void* reg, int protectType)
	{
		MEMORY_BASIC_INFORMATION memInf;

		VirtualQuery((LPCVOID)reg, &memInf, sizeof(memInf));
		VirtualProtect(memInf.BaseAddress, memInf.RegionSize, protectType, &memInf.Protect);
	}

	int Unprotect(void* reg)
	{
		MEMORY_BASIC_INFORMATION memInf;

		VirtualQuery((LPCVOID)reg, &memInf, sizeof(memInf));
		VirtualProtect(memInf.BaseAddress, memInf.RegionSize, PAGE_READWRITE, &memInf.Protect);

		return memInf.Protect;
	}
};

using PaintTraverseFn = void(__stdcall*)(unsigned int, bool, bool);
PaintTraverseFn oPaintTraverse;
