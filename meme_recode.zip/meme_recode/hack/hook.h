#include "hook\paint.h"

namespace Hook
{
	void Run()
	{
		PaintTravers = new Hooked((DWORD**)Panel);

		oPaintTraverse = (PaintTraverseFn)(PaintTravers->HookMethod((DWORD)&PaintTraverse, 41));
	}
}