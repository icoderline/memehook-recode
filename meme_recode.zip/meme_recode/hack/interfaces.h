namespace Interface 
{
	void Run() 
	{
		Get = new Tool;

		Panel = (IPanel*)Get->Interface("vgui2.dll", "VGUI_Panel009");
		Surface = (ISurface*)Get->Interface("vguimatsurface.dll", "VGUI_Surface031");
		Engine = (IVEngineClient*)Get->Interface("engine.dll", "VEngineClient014");
		Cvar = (ICVar*)Get->Interface("vstdlib.dll", "VEngineCvar007");
	}
}