#include "../menu/draw.h"
#include "../menu/menu.h"

int iScreenWidth, iScreenHeight = 0;

void __stdcall PaintTraverse(unsigned int panel, bool forceRepaint, bool allowForce)
{
	oPaintTraverse(panel, forceRepaint, allowForce);

	if (!strcmp("FocusOverlayPanel", Panel->GetName(panel)))
	{

		Engine->GetScreenSize(iScreenWidth, iScreenHeight);

		if (GetAsyncKeyState(VK_INSERT) & 1)
			bMenuOpen = !bMenuOpen;

		if (bMenuOpen)
		{
			bMeme = true;
			HackMenu->Draw(600, 450, iScreenWidth, iScreenHeight);
		}
		else if (bMeme)
		{
			bMeme = false;
			Cvar->FindVar("cl_mouseenable")->SetValue(1);
		}

		if (Engine->IsInGame() && Engine->IsConnected() && Vars::Visuals::Enabled)
		{
			//��� ����� ��������� �������
		}
	}
}
