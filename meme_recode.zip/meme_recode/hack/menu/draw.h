typedef unsigned long HFont;

namespace Draw
{
	void DrawStringA(HFont font, int x, int y, Color color, const char* msg, ...)
	{
		va_list va_alist;
		char buf[1024];
		va_start(va_alist, msg);
		_vsnprintf(buf, sizeof(buf), msg, va_alist);
		va_end(va_alist);
		wchar_t wbuf[1024];
		MultiByteToWideChar(CP_UTF8, 0, buf, 256, wbuf, 256);

		int r = 255, g = 255, b = 255, a = 255;
		color.GetColor(r, g, b, a);

		int Wid, Hit;

		Surface->GetTextSize(font, wbuf, Wid, Hit);
		Surface->DrawSetTextFont(font);
		Surface->DrawSetTextColor(color);
		Surface->DrawSetTextPos(x - Wid / 2, y - Hit / 2);
		Surface->DrawPrintText(wbuf, wcslen(wbuf));
	}

	void DrawStringB(HFont font, int x, int y, Color color, const char* msg, ...)
	{
		va_list va_alist;
		char buf[1024];
		va_start(va_alist, msg);
		_vsnprintf(buf, sizeof(buf), msg, va_alist);
		va_end(va_alist);
		wchar_t wbuf[1024];
		MultiByteToWideChar(CP_UTF8, 0, buf, 256, wbuf, 256);

		int r = 255, g = 255, b = 255, a = 255;
		color.GetColor(r, g, b, a);

		int Wid, Hit;

		Surface->GetTextSize(font, wbuf, Wid, Hit);
		Surface->DrawSetTextFont(font);
		Surface->DrawSetTextColor(color);
		Surface->DrawSetTextPos(x, y - Hit / 2);
		Surface->DrawPrintText(wbuf, wcslen(wbuf));
	}

	void DrawRect(int x, int y, int w, int h, Color col)
	{
		Surface->DrawSetColor(col);
		Surface->DrawFilledRect(x, y, x + w, y + h);
	}

	void DrawOutlinedRect(int x, int y, int w, int h, Color col)
	{
		Surface->DrawSetColor(col);
		Surface->DrawOutlinedRect(x, y, x + w, y + h);
	}

	void DrawLine(int x, int y, int x2, int y2, Color col)
	{
		Surface->DrawSetColor(col);
		Surface->DrawLine(x, y, x2, y2);
	}
}